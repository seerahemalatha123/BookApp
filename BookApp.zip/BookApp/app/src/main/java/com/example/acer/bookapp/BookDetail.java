package com.example.acer.bookapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

public class BookDetail extends AppCompatActivity{
    ImageView imageView;
    TextView textView1,textView2,textView3,textView4;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.book_detail);
        imageView=findViewById(R.id.imageView);
        textView1=findViewById(R.id.title);
        textView2=findViewById(R.id.publisher);
        textView3=findViewById(R.id.publisheddate);
        textView4=findViewById(R.id.description);
        String title=getIntent().getStringExtra("title");
        String publidher=getIntent().getStringExtra("publisher");
        String publishedDate=getIntent().getStringExtra("publisheddate");
        String desc=getIntent().getStringExtra("description");

        Picasso.with(this).load(getIntent().getStringExtra("img")).into(imageView);


        Toast.makeText(this, title, Toast.LENGTH_SHORT).show();


        textView1.setText(title);
        textView2.setText(publidher);
        textView3.setText(publishedDate);
        textView4.setText(desc);

    }
}
