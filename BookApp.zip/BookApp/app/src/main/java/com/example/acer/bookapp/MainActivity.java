package com.example.acer.bookapp;

import android.app.LoaderManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    String link="https://www.googleapis.com/books/v1/volumes?q=android";
    ArrayList<Pojo>arrayList;
    RequestQueue requestQueue;
String thumbnail;
    String publisher,publisheddate,description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recycler);
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));

        requestQueue= Volley.newRequestQueue(this);
        arrayList=new ArrayList<>();
        display();

    }

    public void display(){
        String url="https://www.googleapis.com/books/v1/volumes?q=android";
        StringRequest stringRequest= new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
              //  Toast.makeText(MainActivity.this, "" + response, Toast.LENGTH_SHORT).show();
                try {

                    arrayList = new ArrayList<>();
                    JSONObject root = new JSONObject(response);
                    JSONArray items = root.getJSONArray("items");



                        for (int i = 0; i < items.length(); i++) {
                            JSONObject obj = items.getJSONObject(i);
                            JSONObject jsonObject = obj.getJSONObject("volumeInfo");
                            String title=jsonObject.optString("title");
                            String publisher=jsonObject.optString("publisher");
                           String publisherdate=jsonObject.optString("publishedDate");
                           String description=jsonObject.optString("description");
                            JSONObject imagelinks = jsonObject.getJSONObject("imageLinks");
                            thumbnail = imagelinks.optString("thumbnail");
                           // Toast.makeText(MainActivity.this, " " + thumbnail, Toast.LENGTH_SHORT).show();
                            Pojo book = new Pojo(thumbnail,title,description,publisher,publisherdate);

                            arrayList.add(book);


                    }
                } catch (JSONException exception) {

                }
                MyAdapter adapter = new MyAdapter(MainActivity.this,arrayList);
                recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this,2));
                recyclerView.setAdapter(adapter);

            }
        }
        , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        requestQueue.add(stringRequest);
    }

}
