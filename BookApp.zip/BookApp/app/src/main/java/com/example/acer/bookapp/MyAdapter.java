package com.example.acer.bookapp;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    Context context;
    ArrayList<Pojo> arrayList;

    public MyAdapter(MainActivity mainActivity, ArrayList<Pojo> arrayList) {
        this.arrayList=arrayList;
        this.context=mainActivity;


    }

    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(context).inflate(R.layout.item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Picasso.with(context).load(arrayList.get(position).getThumbnail()).into(holder.imageView);

     //   Toast.makeText(context, ""+arrayList.get(position).getImg_link(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


        ImageView imageView;

        public MyViewHolder(View itemView) {
            super(itemView);
            itemView.setOnClickListener(this);

            imageView=itemView.findViewById(R.id.image);

        }

        @Override
        public void onClick(View v) {

            int pos=getAdapterPosition();

           // Toast.makeText(context, arrayList.get(pos).getTitle(), Toast.LENGTH_SHORT).show();
          //  Pojo pojo=this.pojoArrayList.get(pos);
            Intent intent=new Intent(context,BookDetail.class);
            intent.putExtra("title",  arrayList.get(pos).getTitle());
            intent.putExtra("publisher",arrayList.get(pos).getPublisher());
            intent.putExtra("publisheddate",arrayList.get(pos).getPublisherdate());
            intent.putExtra("description",arrayList.get(pos).getDesc());
            intent.putExtra("img",arrayList.get(pos).getThumbnail());
            context.startActivity(intent);


        }
    }

}
