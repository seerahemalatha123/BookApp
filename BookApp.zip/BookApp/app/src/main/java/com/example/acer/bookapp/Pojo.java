package com.example.acer.bookapp;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Serializable;

public class Pojo implements Serializable{
    String thumbnail;
    String title;
    String publisher;
    String publisherdate;
    String desc;
    public Pojo(String thumbnail, String title, String publisherdate, String description, String publisher) {
        this.thumbnail=thumbnail;
        this.title=title;
        this.publisher=publisher;
        this.desc=description;
        this.publisherdate=publisherdate;
    }



    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPublisherdate() {
        return publisherdate;
    }

    public void setPublisherdate(String publisherdate) {
        this.publisherdate = publisherdate;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
}
